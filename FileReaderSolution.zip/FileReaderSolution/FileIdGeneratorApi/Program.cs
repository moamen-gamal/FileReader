using FileIdGeneratorApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSingleton<IFileGuidGenerator, FileGuidGenerator>();

var app = builder.Build();

app.UseCors("AllowAll");
app.MapControllers();

app.Run();
