﻿namespace FileIdGeneratorApi.Services
{
    public class FileGuidGenerator : IFileGuidGenerator
    {
        private readonly ILogger<FileGuidGenerator> _logger;
        public FileGuidGenerator(ILogger<FileGuidGenerator> logger)
        {
            _logger = logger;
        }

        public Guid SaveFileAndGenerateGuid(IFormFile file)
        {
            if (!Directory.Exists("./resources")) Directory.CreateDirectory("./resources");

            Guid guid = Guid.NewGuid();

            using (Stream fileStream = new FileStream($"./resources/{guid}-{file.FileName}", FileMode.CreateNew))
            {
                file.CopyTo(fileStream);
            }

            return guid;
        }
    }
}
