﻿namespace FileIdGeneratorApi.Services
{
    public interface IFileGuidGenerator
    {
        public Guid SaveFileAndGenerateGuid(IFormFile file);
    }
}
