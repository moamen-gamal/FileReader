﻿using FileIdGeneratorApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace FileIdGeneratorApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FileIdGeneratorController : ControllerBase
    {
        private readonly ILogger<FileIdGeneratorController> _logger;
        private readonly IFileGuidGenerator _fileGuidGenerator;

        public FileIdGeneratorController(ILogger<FileIdGeneratorController> logger, IFileGuidGenerator fileGuidGenerator)
        {
            this._logger = logger;
            this._fileGuidGenerator = fileGuidGenerator;
        }

        [HttpPost]
        public ActionResult ProcessFile([FromForm] IFormFile file)
        {
            try
            {
                if (file == null)
                {
                    _logger.LogInformation($"An Invalid FileProcess Request for null");

                    return BadRequest("Can't process null files.");
                }

                Guid guid = _fileGuidGenerator.SaveFileAndGenerateGuid(file);

                _logger.LogInformation($"Successfully processed and generated Id: {guid} for File: {file.FileName}");

                return Ok(guid.ToString());
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error occured in 'FileIdGeneratorController.ProcessFile': {ex}");
                return BadRequest(ex.Message);
            }
        }
    }
}
