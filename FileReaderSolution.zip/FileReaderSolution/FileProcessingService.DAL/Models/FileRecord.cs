﻿using FileProcessingService.DAL.Enums;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace FileProcessingService.DAL.Models
{
    public class FileRecord
    {
        [Key]
        [Required]
        public int Id { get; set; }

        [NotNull]
        [DefaultValue("")]
        public string Name { get; set; }

        [DefaultValue(FileStatus.NotProcessed)]
        public FileStatus Status { get; set; }

        [AllowNull]
        [DefaultValue(null)]
        public string? FileId { get; set; }
    }
}
