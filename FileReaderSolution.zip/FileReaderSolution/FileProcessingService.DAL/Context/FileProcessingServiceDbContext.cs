﻿using FileProcessingService.DAL.Enums;
using FileProcessingService.DAL.Models;
using Microsoft.EntityFrameworkCore;

namespace FileProcessingService.DAL.Context
{
    public class FileProcessingServiceDbContext : DbContext
    {
        public FileProcessingServiceDbContext(DbContextOptions<FileProcessingServiceDbContext> options) : base(options) { }

        public DbSet<FileRecord> FileRecords { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Make sure the enum is saved correctly according to the model
            modelBuilder.Entity<FileRecord>()
                .Property(record => record.Status)
                .HasConversion<int>(
                    status => (int)status,
                    status => (FileStatus)status
                );

            this.seedData(modelBuilder);
        }

        private void seedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FileRecord>().HasData(new[] {
                new FileRecord { Id = 1, Name = "file1", Status = FileStatus.NotProcessed, FileId = null },
                new FileRecord { Id = 2, Name = "file2", Status = FileStatus.NotProcessed, FileId = null },
                new FileRecord { Id = 3, Name = "file3", Status = FileStatus.NotProcessed, FileId = null },
                new FileRecord { Id = 4, Name = "file4", Status = FileStatus.NotProcessed, FileId = null },
                new FileRecord { Id = 5, Name = "file5", Status = FileStatus.NotProcessed, FileId = null },
                new FileRecord { Id = 6, Name = "file6", Status = FileStatus.NotProcessed, FileId = null },
                new FileRecord { Id = 7, Name = "file7", Status = FileStatus.NotProcessed, FileId = null },
                new FileRecord { Id = 8, Name = "file8", Status = FileStatus.NotProcessed, FileId = null },
                new FileRecord { Id = 9, Name = "file9", Status = FileStatus.NotProcessed, FileId = null }
            });
        }
    }
}
