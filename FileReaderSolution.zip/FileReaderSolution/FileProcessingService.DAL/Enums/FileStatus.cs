﻿namespace FileProcessingService.DAL.Enums
{
    public enum FileStatus
    {
        NotProcessed = 0,
        Processed = 1,
    }
}
