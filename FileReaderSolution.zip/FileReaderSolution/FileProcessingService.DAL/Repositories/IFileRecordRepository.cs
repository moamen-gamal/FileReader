﻿using FileProcessingService.DAL.Models;

namespace FileProcessingService.DAL.Repositories
{
    public interface IFileRecordRepository
    {

        public FileRecord? getFirstNotProcessed(int? previousId);
        public bool updateFileRecordStatus(FileRecord updatedFileRecord);
    }
}
