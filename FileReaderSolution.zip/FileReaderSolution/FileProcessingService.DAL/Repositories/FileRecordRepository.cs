﻿using FileProcessingService.DAL.Context;
using FileProcessingService.DAL.Enums;
using FileProcessingService.DAL.Models;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Logging;
using System.Text;

namespace FileProcessingService.DAL.Repositories
{
    public class FileRecordRepository : IFileRecordRepository
    {
        private readonly FileProcessingServiceDbContext _dbContext;
        private readonly ILogger<FileRecordRepository> _logger;
        public FileRecordRepository(FileProcessingServiceDbContext dbContext, ILogger<FileRecordRepository> logger)
        {
            this._dbContext = dbContext;
            this._logger = logger;
        }

        FileRecord? IFileRecordRepository.getFirstNotProcessed(int? previousId)
        {
            try
            {
                FileRecord? fileRecord;

                if (previousId != null)
                {
                    fileRecord = _dbContext.FileRecords.Where(record => record.Id > previousId && record.Status == FileStatus.NotProcessed).FirstOrDefault();
                }
                else
                {
                    fileRecord = _dbContext.FileRecords.FirstOrDefault((fileRecord) => fileRecord.Status.Equals(FileStatus.NotProcessed));
                }

                if (fileRecord != null)
                {
                    _logger.LogInformation($"Fetched first un-processed file from database with id: {fileRecord.Id}");

                    return fileRecord;
                }
                else
                {
                    StringBuilder stringBuilder = new StringBuilder("No un-processed file fetched from database");
                    if (previousId != null)
                        stringBuilder.Append($" with id after: {previousId}");

                    _logger.LogInformation(stringBuilder.ToString());

                    return null;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get First UnProcessed File with error {ex}");
                throw;
            }
        }
        bool IFileRecordRepository.updateFileRecordStatus(FileRecord updatedFileRecord)
        {
            try
            {
                EntityEntry<FileRecord> _updatedEntity = _dbContext.FileRecords.Update(updatedFileRecord);
                _dbContext.SaveChanges();

                _logger.LogInformation($"successfully updated file with id: {updatedFileRecord?.Id} to the database.");

                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to update FileRecord with Id: {updatedFileRecord?.Id} and with error {ex}");
                throw;
            }
        }
    }
}
