using FileLookupApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSingleton<IFileLookupService, FileLookupService>();

var app = builder.Build();

app.UseAuthorization();

app.MapControllers();

app.Run();
