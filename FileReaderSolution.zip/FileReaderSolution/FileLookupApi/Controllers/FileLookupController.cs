﻿using FileLookupApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace FileLookupApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FileLookupController : ControllerBase
    {
        private readonly ILogger<FileLookupController> _logger;
        private readonly IFileLookupService _fileLookupService;

        public FileLookupController(IFileLookupService fileLookupService, ILogger<FileLookupController> logger)
        {
            this._logger = logger;
            this._fileLookupService = fileLookupService;
        }

        [HttpGet("{id}")]
        public IActionResult GetFileStreamFromId(string id)
        {
            try
            {
                FileStream? fileStream = _fileLookupService.GetFileFromId(int.Parse(id));

                if (fileStream == null)
                {
                    throw new Exception($"Failed to open stream to file with ID: {id}");
                }

                return File(fileStream, "application/octet-stream", Path.GetFileName(fileStream.Name));
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error occured in 'FileLookupController.GetFileStreamFromId': {ex}");
                return BadRequest(ex.Message);
            }
        }


    }
}
