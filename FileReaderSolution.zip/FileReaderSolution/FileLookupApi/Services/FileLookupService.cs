﻿namespace FileLookupApi.Services
{
    public class FileLookupService : IFileLookupService
    {
        private readonly static Dictionary<int, string> _files = new Dictionary<int, string>()
        {
            {1, "./resources/file1.txt" },
            {2, "./resources/file2.txt" },
            {3, "./resources/file3.txt" },
            {4, "./resources/file4.txt" },
            {5, "./resources/file5.txt" },
            {6, "./resources/file6.txt" },
            {7, "./resources/file7.txt" },
            {8, "./resources/file8.txt" },
            {9, "./resources/file9.txt" }
        };

        private readonly ILogger<FileLookupService> _logger;

        public FileLookupService(ILogger<FileLookupService> logger)
        {
            this._logger = logger;
        }

        public FileStream? GetFileFromId(int id)
        {
            try
            {
                if (!_files.ContainsKey(id) || !File.Exists(_files[id]))
                {
                    throw new Exception($"File with id: {id} not found");
                }

                string filePath = _files[id];

                var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);


                if (stream == null)
                {
                    throw new Exception($"Stream to file: {filePath} couldn't be opened");
                }

                return stream;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to get file using ID with error : {ex}");
                return null;
            }
        }
    }
}
