﻿namespace FileLookupApi.Services
{
    public interface IFileLookupService
    {
        public FileStream? GetFileFromId(int id);
    }
}
