using FileProcessingService.DAL.Context;
using FileProcessingService.DAL.Repositories;
using FileProcessingService.Jobs;
using FileProcessingService.Services;
using Microsoft.EntityFrameworkCore;
using NLog.Web;
using Quartz;

var builder = Host.CreateApplicationBuilder(args);

var services = builder.Services;
var configuration = builder.Configuration;

builder.Logging.ClearProviders();
builder.Logging.AddNLog(configuration.GetValue<string>("Logging:LogFilePath"));

services.AddSingleton(provider =>
{
    var options = new DbContextOptionsBuilder<FileProcessingServiceDbContext>()
                    .UseSqlServer(configuration.GetConnectionString("FileProcessingServiceDB"))
                    .Options;

    return new FileProcessingServiceDbContext(options);
});

services.AddSingleton<IFileRecordRepository, FileRecordRepository>();
services.AddSingleton<IFileTransfareService, FileTransfareService>();

services.AddQuartz(q =>
{
    var jobKey = new JobKey(nameof(FileProcessingJob));

    q.AddJob<FileProcessingJob>(opts => opts.WithIdentity(jobKey));

    q.AddTrigger(opts => opts
        .ForJob(jobKey)
        .WithIdentity(jobKey.Name + "-trigger")
        .WithCronSchedule(FileProcessingJob.cronSchedule)
        .StartNow()
    );
});

services.AddQuartzHostedService(q => q.WaitForJobsToComplete = true);

var host = builder.Build();

host.Run();
