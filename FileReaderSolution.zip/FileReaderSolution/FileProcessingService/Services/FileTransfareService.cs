﻿using FileProcessingService.Models;

namespace FileProcessingService.Services
{
    public class FileTransfareService : IFileTransfareService
    {
        private readonly ILogger<FileTransfareService> _logger;
        private readonly IConfiguration _configuration;
        private readonly HttpClient client = new HttpClient();
        private string _fileLookupServiceURL;
        private string _fileIdGeneratorURL;

        public FileTransfareService(ILogger<FileTransfareService> logger, IConfiguration configuration)
        {
            this._fileLookupServiceURL = configuration.GetConnectionString("FileLookupService") ?? "http://localhost:5236/api/FileLookup";
            this._fileIdGeneratorURL = configuration.GetConnectionString("FileIdGeneratorService") ?? "http://localhost:5113/api/FileIdGenerator";
            this._logger = logger;
            this._configuration = configuration;
        }

        public async Task<FileLookupResponse> GetFileFromLookupService(string id)
        {

            HttpResponseMessage getFileStreamResult = await client.GetAsync($"{_fileLookupServiceURL}/{id.ToString()}");

            if (!getFileStreamResult.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to get File stream for file with id: {id} and status code: {getFileStreamResult.StatusCode}");
            }

            string fileName = getFileStreamResult.Content.Headers.ContentDisposition?.FileName ?? $"file{id}.txt";

            if (getFileStreamResult != null)
            {
                _logger.LogTrace($"Wroker fetched file stream for file with id: {id}");

                StreamReader fileStream = new StreamReader(await getFileStreamResult.Content.ReadAsStreamAsync());

                return new FileLookupResponse(fileName, fileStream);
            }
            else
            {
                throw new Exception("Failed to get File from Lookup service");
            }
        }

        public async Task<FileUploadResponse> UploadFileAndGetId(MultipartFormDataContent form)
        {
            HttpResponseMessage getFileIdResult = await client.PostAsync(_fileIdGeneratorURL, form);

            if (!getFileIdResult.IsSuccessStatusCode)
            {
                throw new Exception($"Failed to upload file with status code: {getFileIdResult.StatusCode}");
            }

            return new FileUploadResponse(await getFileIdResult.Content.ReadAsStringAsync());
        }
    }
}
