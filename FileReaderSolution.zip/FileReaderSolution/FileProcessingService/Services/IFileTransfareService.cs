﻿using FileProcessingService.Models;

namespace FileProcessingService.Services
{
    public interface IFileTransfareService
    {
        public Task<FileLookupResponse> GetFileFromLookupService(string id);
        public Task<FileUploadResponse> UploadFileAndGetId(MultipartFormDataContent form);
    }
}
