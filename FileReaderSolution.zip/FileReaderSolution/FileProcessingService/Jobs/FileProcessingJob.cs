using FileProcessingService.DAL.Models;
using FileProcessingService.DAL.Repositories;
using FileProcessingService.Models;
using FileProcessingService.Services;
using FileProcessingService.Utility;
using Quartz;

namespace FileProcessingService.Jobs
{
    public class FileProcessingJob : IJob
    {
        public static string cronSchedule = "0 0/1 * * * ?";

        private readonly ILogger<FileProcessingJob> _logger;
        private readonly IFileRecordRepository _fileRecordRepository;
        private static readonly HttpClient client = new HttpClient();
        private readonly IFileTransfareService _fileTransfareService;
        public FileProcessingJob(ILogger<FileProcessingJob> logger, IFileRecordRepository fileRecordRepository, IFileTransfareService fileTransfareService)
        {
            _logger = logger;
            _fileRecordRepository = fileRecordRepository;
            _fileTransfareService = fileTransfareService;
        }

        public string Name { get; } = nameof(FileProcessingJob);

        private FileRecord? previousFileRecord;

        public async Task Execute(IJobExecutionContext context)
        {
            _logger.LogTrace($"Worker started executing at {DateTime.Now}");
            do
            {
                try
                {

                    FileRecord? fileRecord = RetryUtility.Do(
                        () =>
                        _fileRecordRepository.getFirstNotProcessed(previousFileRecord?.Id ?? null),
                        TimeSpan.FromMilliseconds(500)
                        );

                    previousFileRecord = fileRecord;

                    if (fileRecord != null)
                    {
                        _logger.LogTrace($"Worker fetched File record with id: {fileRecord.Id}");

                        FileLookupResponse fileLookupResponse = await RetryUtility.DoAsync(
                            async () => await _fileTransfareService.GetFileFromLookupService(fileRecord.Id.ToString()),
                            TimeSpan.FromMilliseconds(1000)
                        );

                        using var form = new MultipartFormDataContent();
                        using var fileContent = new StreamContent(fileLookupResponse.fileStream.BaseStream);

                        form.Add(fileContent, "file", fileLookupResponse.fileName);

                        FileUploadResponse fileUploadResponse = await RetryUtility.DoAsync(
                            async () => await _fileTransfareService.UploadFileAndGetId(form),
                            TimeSpan.FromMilliseconds(1000)
                            );

                        fileRecord.Status = DAL.Enums.FileStatus.Processed;
                        fileRecord.FileId = fileUploadResponse.fileId;

                        RetryUtility.Do(
                            () => _fileRecordRepository.updateFileRecordStatus(fileRecord),
                            TimeSpan.FromMilliseconds(500)
                            );

                        _logger.LogTrace($"Worker uploaded file to 'FileIdGenerator' and recieved id: {fileRecord.FileId}");
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Error while executing worker: {ex}");
                }
            } while (previousFileRecord != null);

            _logger.LogTrace($"Worker finished executing at {DateTime.Now}");
        }
    }
}
