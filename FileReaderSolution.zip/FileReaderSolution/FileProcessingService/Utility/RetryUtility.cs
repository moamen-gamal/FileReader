﻿namespace FileProcessingService.Utility
{
    internal class RetryUtility
    {
        public static T Do<T>(Func<T> action, TimeSpan retryInterval, uint maxAttemptCount = 3)
        {
            List<Exception> exceptions = new List<Exception>();
            for (int tries = 0; tries < maxAttemptCount; tries++)
            {
                try
                {
                    if (tries > 0)
                    {
                        Thread.Sleep(retryInterval);
                    }
                    return action();
                }
                catch (Exception e) { exceptions.Add(e); }
            }
            throw new AggregateException(exceptions);
        }

        public static async Task<T> DoAsync<T>(Func<Task<T>> action, TimeSpan retryInterval, uint maxAttemptCount = 3)
        {
            List<Exception> exceptions = new List<Exception>();
            for (int tries = 0; tries < maxAttemptCount; tries++)
            {
                try
                {
                    if (tries > 0)
                    {
                        Thread.Sleep(retryInterval);
                    }
                    return await action();
                }
                catch (Exception e) { exceptions.Add(e); }
            }
            throw new AggregateException(exceptions);
        }
    }
}
