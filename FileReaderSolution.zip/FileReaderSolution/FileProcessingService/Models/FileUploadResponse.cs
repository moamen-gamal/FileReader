﻿namespace FileProcessingService.Models
{
    public class FileUploadResponse
    {
        public string fileId { get; }

        public FileUploadResponse(string fileId)
        {
            this.fileId = fileId;
        }
    }
}
