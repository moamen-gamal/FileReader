﻿namespace FileProcessingService.Models
{
    public class FileLookupResponse
    {
        public string fileName { get; }
        public StreamReader fileStream { get; }

        public FileLookupResponse(string fileName, StreamReader fileStream)
        {
            this.fileName = fileName;
            this.fileStream = fileStream;
        }
    }
}
